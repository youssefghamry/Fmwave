<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Fmwave_Core;
$btn = $attr = '';
extract( $data );
    if ( !empty( $data['buttonurl']['url'] ) ) {
        $attr  = 'href="' . $data['buttonurl']['url'] . '"';
        $attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
        $attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';        
    }
    if ( !empty( $data['buttontext'] ) ) {
        $btn = '<a class="item-btn" ' . $attr . '>' . $data['buttontext'] . '</a>';
    }
?>
<div class="banner-section ">
	<?php if ( $subtitle ) { ?>
    <h3 class="item-subtitle"><?php echo wp_kses_post( $subtitle);?></h3>
    <?php } if ( $title ) { ?>
    <h2 class="item-title"><?php echo wp_kses_post( $title);?></h2>
    <?php } if ( $btn ) { ?>
    <?php echo wp_kses_post( $btn );?>
    <?php } ?>
</div>

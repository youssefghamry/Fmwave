<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Fmwave_Core;
?>
<!-- New HTML -->
<div class="section-defauly-style modern-heading <?php echo esc_attr( $data['alignment'] );?>">
    <<?php echo esc_html( $data['title_tag'] );?> class="heading-title"> <?php echo wp_kses_post( $data['title'] );?> </<?php echo esc_html( $data['title_tag'] );?>>
    <?php if ( $data['subtitle'] ) { ?>
        <p class="section-subtitle"><?php echo wp_kses_post( $data['subtitle'] );?></p>
    <?php } ?>
</div>
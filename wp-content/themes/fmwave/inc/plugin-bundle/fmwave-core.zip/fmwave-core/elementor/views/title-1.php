<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Fmwave_Core;
?>
<div class="section-defauly-style section-heading-1 <?php echo esc_attr( $data['alignment'] );?>">
    <div class="heading-wrap">
        <<?php echo esc_html( $data['title_tag'] );?> class="heading-title"> <?php echo wp_kses_post( $data['title'] );?> </<?php echo esc_html( $data['title_tag'] );?>>
        <div class="singnal-symbol">
            <div class="item-circle circle-1"></div>
            <div class="item-circle circle-2"></div>
            <div class="item-circle circle-3"></div>
        </div>
    </div>
    <?php  if ($data['subtitle']) { ?>
        <p class="section-subtitle"><?php echo wp_kses_post( $data['subtitle'] );?></p>
    <?php } ?>
</div>

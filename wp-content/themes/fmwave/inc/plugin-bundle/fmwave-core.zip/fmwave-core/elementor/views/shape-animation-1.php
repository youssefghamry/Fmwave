<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Fmwave_Core;
use radiustheme\Fmwave\Helper;

?>
<div class="shape-animation-layouts animation-<?php echo esc_attr( $data['layout'] ); ?>">
    <div class="shape-img">
        <img width="117" height="80" loading="lazy" class="img-animate left-img1" src="<?php echo Helper::get_img('element/shape1.png'); ?>" alt="Shape" data-sal="slide-right" data-sal-duration="1000">
        <img width="107" height="106" loading="lazy" class="img-animate left-img2" src="<?php echo Helper::get_img('element/shape2.png'); ?>" alt="Shape" data-sal="slide-right" data-sal-duration="1000" data-sal-delay="100">
        <img width="90" height="90" loading="lazy" class="img-animate left-img3" src="<?php echo Helper::get_img('element/shape3.png'); ?>" alt="Shape" data-sal="slide-right" data-sal-duration="1000" data-sal-delay="200">
        <img width="74" height="69" loading="lazy" class="img-animate right-img1" src="<?php echo Helper::get_img('element/shape4.png'); ?>" alt="Shape" data-sal="slide-left" data-sal-duration="1000">
        <img width="82" height="82" loading="lazy" class="img-animate right-img2" src="<?php echo Helper::get_img('element/shape5.png'); ?>" alt="Shape" data-sal="slide-left" data-sal-duration="1000" data-sal-delay="100">
        <img width="70" height="77" loading="lazy" class="img-animate right-img3" src="<?php echo Helper::get_img('element/shape6.png'); ?>" alt="Shape" data-sal="slide-left" data-sal-duration="1000" data-sal-delay="200">
    </div>
</div>


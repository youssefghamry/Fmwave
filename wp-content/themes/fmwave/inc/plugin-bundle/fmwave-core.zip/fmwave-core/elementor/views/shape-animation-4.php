<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Fmwave_Core;
use radiustheme\Fmwave\Helper;

?>
<div class="shape-animation-layouts animation-<?php echo esc_attr( $data['layout'] ); ?>">
    <div class="shape-img">
        <img width="482" height="261" loading="lazy" class="img-animate right-img1" src="<?php echo Helper::get_img('element/team_home4_bg_right.png'); ?>" alt="Shape16" data-sal="slide-right" data-sal-duration="1000">
        <img width="412" height="350" loading="lazy" class="img-animate right-img2" src="<?php echo Helper::get_img('element/team_home4_bg_left.png'); ?>" alt="Shape17" data-sal="slide-right" data-sal-duration="1000" data-sal-delay="100">
    </div>
</div>


<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Fmwave_Core;
use radiustheme\Fmwave\Helper;

?>
<div class="shape-animation-layouts animation-<?php echo esc_attr( $data['layout'] ); ?>">
    <div class="shape-img">
        <img width="20" height="20" loading="lazy" class="img-animate left-img1" src="<?php echo Helper::get_img('element/shape8.png'); ?>" alt="Shape8" data-sal="slide-right" data-sal-duration="1000">
        <img width="16" height="14" loading="lazy" class="img-animate left-img2" src="<?php echo Helper::get_img('element/shape9.png'); ?>" alt="Shape9" data-sal="slide-right" data-sal-duration="1000" data-sal-delay="100">
        <img width="81" height="82" loading="lazy" class="img-animate left-img3" src="<?php echo Helper::get_img('element/shape10.png'); ?>" alt="Shape10" data-sal="slide-right" data-sal-duration="1000" data-sal-delay="200">
        <img width="43" height="43" loading="lazy" class="img-animate right-img1" src="<?php echo Helper::get_img('element/shape11.png'); ?>" alt="Shape11" data-sal="slide-left" data-sal-duration="1000">
        <img width="111" height="112" loading="lazy" class="img-animate right-img2" src="<?php echo Helper::get_img('element/shape12.png'); ?>" alt="Shape12" data-sal="slide-left" data-sal-duration="1000" data-sal-delay="100">
    </div>
</div>


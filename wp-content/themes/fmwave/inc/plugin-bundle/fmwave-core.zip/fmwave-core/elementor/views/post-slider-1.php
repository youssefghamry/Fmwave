<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Fmwave_Core;
use \WP_Query;
use radiustheme\fmwave\RDTheme;
use radiustheme\fmwave\Helper;

$thumb_size = FMWAVE_CORE_THEME . '-size2';
$args = array(
	'posts_per_page' => $data['number'],
	'cat'            => (int) $data['cat'],
	'orderby'        => $data['orderby'],
);
switch ( $data['orderby'] ) {
	case 'title':
	case 'menu_order':
	$args['order'] = 'ASC';
	break;
}

$query = new WP_Query( $args );
$class = $data['slider_nav'] == 'yes' ? ' slider-nav-enabled' : '';
$temp = Helper::wp_set_temp_query( $query );
?>
<div class="rt-el-blgo-post owl-wrap nav-control-layout-top rt-owl-dot  <?php echo esc_attr( $class );?>">
	<div class="owl-theme owl-carousel rt-owl-carousel" data-carousel-options="<?php echo esc_attr( $data['owl_data'] );?>">
		<?php if ( $query->have_posts() ) :?>
			<?php while ( $query->have_posts() ) : $query->the_post();?>
				<?php
				$content = Helper::get_current_post_content();
				$content = wp_trim_words( $content, $data['count'] );
				$content = "<p>$content</p>";
				$comments_number = number_format_i18n( get_comments_number() );
				$comments_html   = $comments_number < 2 ? esc_html__( 'Comment' , 'fmwave-core' ) : esc_html__( 'Comments' , 'fmwave-core' );
				$comments_html  .= ': '. $comments_number;
				?>

				<div class="rtin-item">	
					<div class="blog-box-layout1 blog-box-wrp">				   
							<?php if ( has_post_thumbnail() ){?>
						    <div class="item-img">	
										<a href="<?php the_permalink();?>">
												<?php the_post_thumbnail( $thumb_size ); ?>
										</a>
										<?php if ( $data['meta']  == 'yes' ): ?>							 
											<?php if ( RDTheme::$options['blog_date'] ): ?>
												<div class="top-item">
													<div class="item-date">
															<?php the_time( get_option( 'date_format' ) );?>
													</div>
												</div>
											<?php endif; ?>		
									<?php endif ?>
							</div>
						<?php } ?>
					    <div class="item-content">
				    		<?php if ( $data['show_category']  == 'yes' ): ?>		
				         		<?php Helper::fmwave_category_prepare();?>			
				        <?php endif ?>	  
					        <<?php echo esc_html( $data['title_tag'] );?> class="item-title"
												<a href="<?php the_permalink();?>"><?php the_title();?></a>
					        </<?php echo esc_html( $data['title_tag'] );?>> 

											<?php if ( $data['show_content']  == 'yes' ): ?>			
												<?php echo wp_kses_post( $content );?>
											<?php endif ?>	
									<?php
										echo Helper::rt_get_post_meta($data, $post_id );
									?>
					    </div>
					</div>
				</div>	

			<?php endwhile;?>
		<?php endif;?>
		<?php Helper::wp_reset_temp_query( $temp );?>
	</div>
</div>
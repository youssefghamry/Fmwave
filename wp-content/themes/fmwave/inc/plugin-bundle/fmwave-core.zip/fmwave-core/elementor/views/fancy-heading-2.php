<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Fmwave_Core;
$btn = $attr = '';
if ( !empty( $data['buttonurl']['url'] ) ) {
	$attr  = 'href="' . $data['buttonurl']['url'] . '"';
	$attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';
	
}
if ( !empty( $data['buttontext'] ) ) {
	$btn = '<a class="item-btn" ' . $attr . '>' . $data['buttontext'] . '</a>';
}
?>
<div class="hero-content-default hero-content-2">
	<?php if($data['top_title']){ ?>
	<div class="sub-title"><?php echo $data['top_title'] ;?></div>
	<?php } ?>
	<?php if($data['title']){ ?>
        <<?php esc_html_e( $data['title_tag'] ); ?> class="item-title"><?php echo $data['title'] ;?></<?php esc_html_e( $data['title_tag'] ); ?>>
	<?php } ?>
	<?php if($data['content']){ ?>
        <div class="rtr-content"><?php echo $data['content']; ?></div>
	<?php } ?>
    <?php if ( $btn ) { ?><?php echo $btn; ?><?php } ?>
</div>
<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Fmwave_Core;
use radiustheme\Fmwave\Helper;

?>
<div class="shape-animation-layouts animation-<?php echo esc_attr( $data['layout'] ); ?>">
    <div class="shape-img">
        <img width="60" height="52" loading="lazy" class="img-animate right-img1" src="<?php echo Helper::get_img('element/shape16.png'); ?>" alt="Shape16" data-sal="slide-right" data-sal-duration="1000">
        <img width="89" height="91" loading="lazy" class="img-animate right-img2" src="<?php echo Helper::get_img('element/shape17.png'); ?>" alt="Shape17" data-sal="slide-right" data-sal-duration="1000" data-sal-delay="100">
        <img width="27" height="72" loading="lazy" class="img-animate right-img3" src="<?php echo Helper::get_img('element/shape18.png'); ?>" alt="Shape18" data-sal="slide-right" data-sal-duration="1000" data-sal-delay="200">
        <img width="86" height="60" loading="lazy" class="img-animate right-img4" src="<?php echo Helper::get_img('element/shape19.png'); ?>" alt="Shape19" data-sal="slide-left" data-sal-duration="1000">
    </div>
</div>


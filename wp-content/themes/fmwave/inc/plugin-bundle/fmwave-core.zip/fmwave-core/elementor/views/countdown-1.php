<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Fmwave_Core;


?>
<div class="countdown-default rt-countdown-layout1 rt-countdown">
	<?php if (!empty($data['date_time'])): ?>
		<div class="countdown fmwave-countdown" data-date="<?php echo esc_attr( $data['date_time'] ); ?>" ></div>
	<?php endif; ?>
</div>


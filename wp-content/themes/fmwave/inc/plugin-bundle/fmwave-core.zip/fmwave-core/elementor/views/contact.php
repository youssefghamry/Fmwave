<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Fmwave_Core;
?>
<div class="contact-method">
	<?php if( $data['title'] ){ ?><h2 class="item-heading"><?php echo wp_kses_post( $data['title'] ); ?></h2><?php } ?>
	<?php if ( !empty( $data['content'] ) ) { ?>
        <p class="rtin-text"><?php echo wp_kses_post( $data['content'] );?></p>
	<?php } ?>
    <div class="contact-list">
	    <?php if( !empty( $data['address'] ) || !empty( $data['address2'] ) ){ ?>
        <div class="media">
            <div class="item-icon">
                <i class="flaticon-architecture-and-city"></i>
            </div>
            <div class="media-body">
                <h3 class="item-title"><?php echo wp_kses_post( $data['address_label'] ); ?></h3>
	            <?php if( $data['address'] ){ ?>
                    <p><?php echo wp_kses_post( $data['address'] ); ?></p>
                <?php } if( $data['address2'] ){ ?>
                    <p><?php echo wp_kses_post( $data['address2'] ); ?></p>
                <?php } ?>
            </div>
        </div>
        <?php } ?>
	    <?php if( !empty( $data['phone'] ) || !empty( $data['phone2'] ) ){ ?>
        <div class="media">
            <div class="item-icon">
                <i class="flaticon-phone"></i>
            </div>
            <div class="media-body">
	            <?php if( $data['phone_label'] ){ ?><h3 class="item-title"><?php echo wp_kses_post( $data['phone_label'] ); ?></h3><?php } ?>
                <p><?php if( $data['phone'] ){ echo wp_kses_post( $data['phone'] ); } ?><?php if( $data['phone2'] ){ echo ' ,' . wp_kses_post( $data['phone2'] ); } ?></p>
            </div>
        </div>
        <?php } ?>
	    <?php if( !empty( $data['email'] ) || !empty( $data['email2'] ) ){ ?>
        <div class="media">
            <div class="item-icon">
                <i class="flaticon-plane"></i>
            </div>
            <div class="media-body">
	            <?php if( $data['email_label'] ){ ?><h3 class="item-title"><?php echo wp_kses_post( $data['email_label'] ); ?></h3><?php } ?>
	            <?php if( $data['email'] ){ ?>
                    <p><?php echo wp_kses_post( $data['email'] ); ?></p>
	            <?php } if( $data['email2'] ){ ?>
                 <p><?php echo wp_kses_post( $data['email2'] ); ?></p>
                <?php } ?>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
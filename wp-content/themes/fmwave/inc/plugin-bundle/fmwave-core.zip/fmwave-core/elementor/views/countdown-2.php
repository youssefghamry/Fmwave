<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Fmwave_Core;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
extract( $data );


$getimg3 = Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size', 'rt_image' );

?>
<div class="event-box">
    <div class="media">
        <div class="item-img">
            <?php echo wp_kses_post($getimg3);?>
        </div>
        <div class="media-body">
            <?php if ( !empty( $data['countdown_title'] ) ) { ?>
                <h2 class="item-title"><?php echo esc_html( $data['countdown_title'] ); ?></h2>
            <?php } ?>

            <div class="rt-countdown-layout2 rt-countdown">
                <?php if (!empty($data['date_time'])): ?>
					<div class="countdown fmwave-countdown" data-date="<?php echo esc_attr( $data['date_time'] ); ?>"></div>
				<?php endif; ?>
            </div>

        </div>
    </div>
</div>
<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Fmwave_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use radiustheme\Fmwave\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Slider extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = __( 'Slider', 'fmwave-core' );
		$this->rt_base = 'rt-slider';
		parent::__construct( $data, $args );
	}

	private function rt_load_scripts(){
		wp_enqueue_style(  'fmwave-nivo-slider' );
		wp_enqueue_script( 'jquery-nivo-slider' );
		wp_enqueue_script( 'fmwave-nivo-home' );
	}

	public function rt_fields(){
		$fields = array(		
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_layout',
				'label'   => esc_html__( 'General', 'fmwave-core' ),
			),
			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'banner_list',
				'label'   => esc_html__( 'Add as many slide as you want', 'fmwave-core' ),
				'fields'  => array(
					array(
						'type'    => Controls_Manager::MEDIA,
						'name'      => 'banner_image',
						'label'   => esc_html__( 'Banner Image', 'fmwave-core' ),
						'description' => esc_html__( 'Recommended image size is 1920px X 880px', 'fmwave-core' ),
					),
					array(
						'type'    => Controls_Manager::TEXTAREA,
						'name'    => 'banner_text',
						'label'   => esc_html__( 'Banner Text', 'fmwave-core' ),
						'default' => '<span>THERE IS ALWAYS</span> Something Great Idea Work...',
					),
					array(
						'type'    => Controls_Manager::TEXT,
						'name'      => 'button_text',
						'label'   => esc_html__( 'Button Text', 'fmwave-core' ),
						'default' => esc_html__( 'BY THIS THEME', 'fmwave-core' ),
					),
					array(
						'type'    => Controls_Manager::URL,
						'name'      => 'button_url',
						'label'   => esc_html__( 'Button URL', 'fmwave-core' ),
						'placeholder' => esc_url('https://your-link.com' ),
					),
					array(
						'type'    => Controls_Manager::TEXT,
						'name'      => 'show_time',
						'label'   => esc_html__( 'Time', 'fmwave-core' ),
						'default' => esc_html__('Sun-Thu 12 pm', 'fmwave-core' ),
					),
					array(
						'type'    => Controls_Manager::TEXTAREA,
						'name'      => 'show_title',
						'label'   => esc_html__( 'Title', 'fmwave-core' ),
						'default' => esc_html__('With Jazmyne Shields', 'fmwave-core' ),
					),

				),
			),

			array(
				'mode' => 'section_end',
			),

		);
		return $fields;
	}

	protected function render() {

		$data = $this->get_settings();
		$this->rt_load_scripts();
		$template = 'slider';
		return $this->rt_template( $template, $data );

	}
}
<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Fmwave_Core;
use radiustheme\Fmwave\Helper;
use Elementor\Group_Control_Image_Size;

$img = Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );

?>
<div class="about-img">
	<?php echo wp_kses_post($img); ?>
    <div class="video-icon">
        <a class="play-btn popup-youtube" href="<?php echo esc_url( $data['videourl']);?>">
            <i class="fas fa-play"></i>
        </a>
    </div>
</div>
<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Fmwave_Core;  
?>
<div class="about-box-layout2">
	<?php if ($data['subtitle']): ?>
		<div class="item-subtitle"><?php echo wp_kses_post( $data['subtitle'] );?></div>
	<?php endif ?> 	 
    <<?php echo esc_html( $data['title_tag'] );?> class="item-title">
    <?php echo wp_kses_post( $data['title'] );?>
    </<?php echo esc_html( $data['title_tag'] );?>> 		
	<?php if ($data['paragraph']): ?>
		<div class="rtin-paragraph"><?php echo wp_kses_post( $data['paragraph'] );?></div>        
	<?php endif ?> 	   
</div>